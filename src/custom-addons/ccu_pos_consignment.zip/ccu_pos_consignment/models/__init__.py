# Copyright (C) 2023 CCU
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl).
from . import account_move
from . import product_template
from . import stock_picking
from . import pos_order
from . import pos_session
