# -*- coding: utf-8 -*-

from . import generic_invoice_report
from . import pos_invoice_report
from . import account_invoice_report
